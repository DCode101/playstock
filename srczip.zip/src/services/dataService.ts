import { doc, setDoc, collection, getDocs, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Driver, Race } from '../types';

// Real F1 2024 Drivers with official data
export const INITIAL_DRIVERS: Driver[] = [
  {
    id: 'max_verstappen',
    name: 'Max Verstappen',
    driverNumber: 1,
    team: 'Red Bull Racing',
    nationality: 'Dutch',
    price: 5500,
    basePrice: 5500,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 1,
    wins: 0,
    podiums: 0,
    teamColor: '#3671C6',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/verstappen.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/verstappen.jpg',
    risk: 'low',
    history: [],
    attributes: { speed: 98, experience: 90, aggression: 75, consistency: 96, fanbase: 95 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'sergio_perez',
    name: 'Sergio Perez',
    driverNumber: 11,
    team: 'Red Bull Racing',
    nationality: 'Mexican',
    price: 3200,
    basePrice: 3200,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 2,
    wins: 0,
    podiums: 0,
    teamColor: '#3671C6',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/perez.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/perez.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 85, experience: 88, aggression: 68, consistency: 78, fanbase: 87 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'lewis_hamilton',
    name: 'Lewis Hamilton',
    driverNumber: 44,
    team: 'Mercedes',
    nationality: 'British',
    price: 4800,
    basePrice: 4800,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 3,
    wins: 0,
    podiums: 0,
    teamColor: '#27F4D2',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/hamilton.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/hamilton.jpg',
    risk: 'low',
    history: [],
    attributes: { speed: 94, experience: 99, aggression: 70, consistency: 92, fanbase: 99 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'george_russell',
    name: 'George Russell',
    driverNumber: 63,
    team: 'Mercedes',
    nationality: 'British',
    price: 3400,
    basePrice: 3400,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 4,
    wins: 0,
    podiums: 0,
    teamColor: '#27F4D2',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/russell.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/russell.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 89, experience: 75, aggression: 82, consistency: 85, fanbase: 82 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'charles_leclerc',
    name: 'Charles Leclerc',
    driverNumber: 16,
    team: 'Ferrari',
    nationality: 'Monegasque',
    price: 4200,
    basePrice: 4200,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 5,
    wins: 0,
    podiums: 0,
    teamColor: '#E8002D',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/leclerc.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/leclerc.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 96, experience: 78, aggression: 88, consistency: 82, fanbase: 93 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'carlos_sainz',
    name: 'Carlos Sainz',
    driverNumber: 55,
    team: 'Ferrari',
    nationality: 'Spanish',
    price: 3600,
    basePrice: 3600,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 6,
    wins: 0,
    podiums: 0,
    teamColor: '#E8002D',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/sainz.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/sainz.jpg',
    risk: 'low',
    history: [],
    attributes: { speed: 88, experience: 82, aggression: 72, consistency: 89, fanbase: 85 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'lando_norris',
    name: 'Lando Norris',
    driverNumber: 4,
    team: 'McLaren',
    nationality: 'British',
    price: 3800,
    basePrice: 3800,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 7,
    wins: 0,
    podiums: 0,
    teamColor: '#FF8000',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/norris.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/norris.jpg',
    risk: 'low',
    history: [],
    attributes: { speed: 92, experience: 76, aggression: 79, consistency: 90, fanbase: 94 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Strong Buy',
    recentTrades: []
  },
  {
    id: 'oscar_piastri',
    name: 'Oscar Piastri',
    driverNumber: 81,
    team: 'McLaren',
    nationality: 'Australian',
    price: 2800,
    basePrice: 2800,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 8,
    wins: 0,
    podiums: 0,
    teamColor: '#FF8000',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/piastri.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/piastri.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 90, experience: 62, aggression: 74, consistency: 88, fanbase: 80 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'fernando_alonso',
    name: 'Fernando Alonso',
    driverNumber: 14,
    team: 'Aston Martin',
    nationality: 'Spanish',
    price: 3300,
    basePrice: 3300,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 9,
    wins: 0,
    podiums: 0,
    teamColor: '#229971',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/alonso.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/alonso.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 87, experience: 99, aggression: 85, consistency: 92, fanbase: 91 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'lance_stroll',
    name: 'Lance Stroll',
    driverNumber: 18,
    team: 'Aston Martin',
    nationality: 'Canadian',
    price: 2200,
    basePrice: 2200,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 10,
    wins: 0,
    podiums: 0,
    teamColor: '#229971',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/stroll.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/stroll.jpg',
    risk: 'high',
    history: [],
    attributes: { speed: 78, experience: 76, aggression: 84, consistency: 65, fanbase: 62 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'pierre_gasly',
    name: 'Pierre Gasly',
    driverNumber: 10,
    team: 'Alpine',
    nationality: 'French',
    price: 2400,
    basePrice: 2400,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 11,
    wins: 0,
    podiums: 0,
    teamColor: '#FF87BC',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/gasly.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/gasly.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 81, experience: 78, aggression: 79, consistency: 76, fanbase: 75 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'esteban_ocon',
    name: 'Esteban Ocon',
    driverNumber: 31,
    team: 'Alpine',
    nationality: 'French',
    price: 2300,
    basePrice: 2300,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 12,
    wins: 0,
    podiums: 0,
    teamColor: '#FF87BC',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/ocon.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/ocon.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 80, experience: 79, aggression: 86, consistency: 74, fanbase: 72 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'alexander_albon',
    name: 'Alexander Albon',
    driverNumber: 23,
    team: 'Williams',
    nationality: 'Thai',
    price: 2500,
    basePrice: 2500,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 13,
    wins: 0,
    podiums: 0,
    teamColor: '#64C4FF',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/albon.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/albon.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 85, experience: 74, aggression: 72, consistency: 85, fanbase: 80 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'logan_sargeant',
    name: 'Logan Sargeant',
    driverNumber: 2,
    team: 'Williams',
    nationality: 'American',
    price: 1800,
    basePrice: 1800,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 14,
    wins: 0,
    podiums: 0,
    teamColor: '#64C4FF',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/sargeant.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/sargeant.jpg',
    risk: 'high',
    history: [],
    attributes: { speed: 75, experience: 58, aggression: 70, consistency: 68, fanbase: 65 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'yuki_tsunoda',
    name: 'Yuki Tsunoda',
    driverNumber: 22,
    team: 'RB',
    nationality: 'Japanese',
    price: 2100,
    basePrice: 2100,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 15,
    wins: 0,
    podiums: 0,
    teamColor: '#6692FF',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/tsunoda.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/tsunoda.jpg',
    risk: 'high',
    history: [],
    attributes: { speed: 84, experience: 68, aggression: 92, consistency: 71, fanbase: 82 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'daniel_ricciardo',
    name: 'Daniel Ricciardo',
    driverNumber: 3,
    team: 'RB',
    nationality: 'Australian',
    price: 2600,
    basePrice: 2600,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 16,
    wins: 0,
    podiums: 0,
    teamColor: '#6692FF',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/ricciardo.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/ricciardo.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 80, experience: 92, aggression: 70, consistency: 78, fanbase: 98 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'nico_hulkenberg',
    name: 'Nico Hulkenberg',
    driverNumber: 27,
    team: 'Haas',
    nationality: 'German',
    price: 2200,
    basePrice: 2200,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 17,
    wins: 0,
    podiums: 0,
    teamColor: '#B6BABD',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/hulkenberg.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/hulkenberg.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 85, experience: 86, aggression: 72, consistency: 88, fanbase: 72 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Buy',
    recentTrades: []
  },
  {
    id: 'kevin_magnussen',
    name: 'Kevin Magnussen',
    driverNumber: 20,
    team: 'Haas',
    nationality: 'Danish',
    price: 1900,
    basePrice: 1900,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 18,
    wins: 0,
    podiums: 0,
    teamColor: '#B6BABD',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/magnussen.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/magnussen.jpg',
    risk: 'high',
    history: [],
    attributes: { speed: 81, experience: 82, aggression: 94, consistency: 68, fanbase: 74 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'valtteri_bottas',
    name: 'Valtteri Bottas',
    driverNumber: 77,
    team: 'Sauber',
    nationality: 'Finnish',
    price: 2400,
    basePrice: 2400,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 19,
    wins: 0,
    podiums: 0,
    teamColor: '#52E252',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/bottas.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/bottas.jpg',
    risk: 'medium',
    history: [],
    attributes: { speed: 80, experience: 88, aggression: 65, consistency: 82, fanbase: 78 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  },
  {
    id: 'guanyu_zhou',
    name: 'Guanyu Zhou',
    driverNumber: 24,
    team: 'Sauber',
    nationality: 'Chinese',
    price: 1700,
    basePrice: 1700,
    change: 0,
    changePercent: 0,
    points: 0,
    rank: 20,
    wins: 0,
    podiums: 0,
    teamColor: '#52E252',
    helmetImg: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/manual/Helmets2024/zhou.png',
    photo: 'https://media.formula1.com/d_driver_fallback_image.png/content/dam/fom-website/drivers/2024Drivers/zhou.jpg',
    risk: 'high',
    history: [],
    attributes: { speed: 76, experience: 68, aggression: 65, consistency: 78, fanbase: 70 },
    marketCap: 0,
    volume24h: 0,
    rsi: 50,
    sentiment: 'neutral',
    rating: 'Hold',
    recentTrades: []
  }
];

// Generate race schedule from today to Feb 28, 2026
export const generateMockSchedule = (): Race[] => {
  const circuits = [
    { name: 'Bahrain Grand Prix', location: 'Sakhir', country: 'Bahrain', circuitId: 'bahrain' },
    { name: 'Saudi Arabian Grand Prix', location: 'Jeddah', country: 'Saudi Arabia', circuitId: 'jeddah' },
    { name: 'Australian Grand Prix', location: 'Melbourne', country: 'Australia', circuitId: 'albert_park' },
    { name: 'Japanese Grand Prix', location: 'Suzuka', country: 'Japan', circuitId: 'suzuka' },
    { name: 'Chinese Grand Prix', location: 'Shanghai', country: 'China', circuitId: 'shanghai' },
    { name: 'Miami Grand Prix', location: 'Miami', country: 'USA', circuitId: 'miami' },
    { name: 'Emilia Romagna Grand Prix', location: 'Imola', country: 'Italy', circuitId: 'imola' },
    { name: 'Monaco Grand Prix', location: 'Monaco', country: 'Monaco', circuitId: 'monaco' },
    { name: 'Canadian Grand Prix', location: 'Montreal', country: 'Canada', circuitId: 'villeneuve' },
    { name: 'Spanish Grand Prix', location: 'Barcelona', country: 'Spain', circuitId: 'catalunya' },
    { name: 'Austrian Grand Prix', location: 'Spielberg', country: 'Austria', circuitId: 'red_bull_ring' },
    { name: 'British Grand Prix', location: 'Silverstone', country: 'UK', circuitId: 'silverstone' },
    { name: 'Hungarian Grand Prix', location: 'Budapest', country: 'Hungary', circuitId: 'hungaroring' },
    { name: 'Belgian Grand Prix', location: 'Spa', country: 'Belgium', circuitId: 'spa' },
    { name: 'Dutch Grand Prix', location: 'Zandvoort', country: 'Netherlands', circuitId: 'zandvoort' },
    { name: 'Italian Grand Prix', location: 'Monza', country: 'Italy', circuitId: 'monza' },
    { name: 'Azerbaijan Grand Prix', location: 'Baku', country: 'Azerbaijan', circuitId: 'baku' },
    { name: 'Singapore Grand Prix', location: 'Singapore', country: 'Singapore', circuitId: 'marina_bay' },
    { name: 'United States Grand Prix', location: 'Austin', country: 'USA', circuitId: 'americas' },
    { name: 'Mexico City Grand Prix', location: 'Mexico City', country: 'Mexico', circuitId: 'rodriguez' },
  ];

  const races: Race[] = [];
  const today = new Date();
  const endDate = new Date('2026-02-28');
  
  let currentDate = new Date(today);
  let round = 1;
  let circuitIndex = 0;

  while (currentDate <= endDate && round <= 20) {
    // Schedule races every 3-4 days
    const daysToAdd = 3 + Math.floor(Math.random() * 2);
    currentDate.setDate(currentDate.getDate() + daysToAdd);

    if (currentDate > endDate) break;

    const circuit = circuits[circuitIndex % circuits.length];
    const raceDate = new Date(currentDate);
    raceDate.setHours(14, 0, 0, 0); // Race at 2 PM

    races.push({
      round,
      raceName: circuit.name,
      circuit: {
        circuitId: circuit.circuitId,
        circuitName: circuit.name,
        location: circuit.location,
        country: circuit.country,
        lat: '0',
        long: '0'
      },
      date: raceDate.toISOString().split('T')[0],
      time: '14:00:00Z',
      completed: raceDate < today,
      isLive: false
    });

    round++;
    circuitIndex++;
  }

  return races;
};

// Initialize Firebase with drivers and schedule
export const initializeDatabase = async () => {
  try {
    // Check if already initialized
    const driversRef = collection(db, 'drivers');
    const driversSnapshot = await getDocs(driversRef);
    
    if (driversSnapshot.empty) {
      console.log('Initializing database...');
      
      // Add all drivers
      for (const driver of INITIAL_DRIVERS) {
        await setDoc(doc(db, 'drivers', driver.id), driver);
      }
      
      // Add race schedule
      const schedule = generateMockSchedule();
      for (const race of schedule) {
        await setDoc(doc(db, 'schedule', `race_${race.round}`), race);
      }

      // Initialize market state
      await setDoc(doc(db, 'market', 'state'), {
        vix: 45,
        sentiment: 'bullish',
        activeConnections: 0,
        globalVolume: 0,
        topMovers: {
          gainers: [],
          losers: []
        },
        lastUpdated: Date.now()
      });

      console.log('Database initialized successfully!');
    }
  } catch (error) {
    console.error('Error initializing database:', error);
  }
};

// Fetch real leaderboard from Firestore
export const fetchRealLeaderboard = async () => {
  try {
    const usersRef = collection(db, 'users');
    const usersSnapshot = await getDocs(usersRef);
    
    const leaderboard = usersSnapshot.docs.map(doc => {
      const data = doc.data();
      const netWorth = (data.balance || 100000) + (data.portfolio || []).reduce((sum: number, item: any) => {
        return sum + (item.currentValue || 0);
      }, 0);
      
      return {
        userId: doc.id,
        username: data.username || 'Anonymous',
        netWorth,
        balance: data.balance || 100000,
        portfolioValue: netWorth - (data.balance || 100000),
        change: netWorth - 100000,
        changePercent: ((netWorth - 100000) / 100000) * 100,
        createdAt: data.createdAt || Date.now()
      };
    }).sort((a, b) => b.netWorth - a.netWorth);

    return leaderboard.map((user, index) => ({
      ...user,
      rank: index + 1
    }));
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return [];
  }
};

// Fetch drivers from Firestore
export const fetchDrivers = async (): Promise<Driver[]> => {
  try {
    const driversRef = collection(db, 'drivers');
    const driversSnapshot = await getDocs(driversRef);
    
    return driversSnapshot.docs.map(doc => doc.data() as Driver);
  } catch (error) {
    console.error('Error fetching drivers:', error);
    return INITIAL_DRIVERS;
  }
};

// Fetch schedule from Firestore
export const fetchSchedule = async (): Promise<Race[]> => {
  try {
    const scheduleRef = collection(db, 'schedule');
    const scheduleSnapshot = await getDocs(scheduleRef);
    
    const races = scheduleSnapshot.docs.map(doc => doc.data() as Race);
    return races.sort((a, b) => a.round - b.round);
  } catch (error) {
    console.error('Error fetching schedule:', error);
    return generateMockSchedule();
  }
};