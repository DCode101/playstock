import React, { useState } from 'react';
import { Gamepad2, Trophy, Target, Zap, Star, Gift } from 'lucide-react';
import { motion } from 'framer-motion';

const Games: React.FC = () => {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const games = [
    {
      id: 'quiz',
      title: 'F1 Trivia Challenge',
      description: 'Test your Formula 1 knowledge and earn bonus credits',
      icon: '🧠',
      reward: '$500',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 'predict',
      title: 'Race Predictor',
      description: 'Predict the top 3 finishers in the next race',
      icon: '🔮',
      reward: '$1,000',
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: 'daily',
      title: 'Daily Challenge',
      description: 'Complete daily trading challenges for rewards',
      icon: '📅',
      reward: '$750',
      color: 'from-green-500 to-green-600'
    },
    {
      id: 'strategy',
      title: 'Pit Stop Strategy',
      description: 'Make the right pit stop calls to win the race',
      icon: '⏱️',
      reward: '$1,500',
      color: 'from-orange-500 to-orange-600'
    }
  ];

  const quizQuestions = [
    {
      question: 'Who holds the record for most F1 World Championships?',
      options: ['Lewis Hamilton', 'Michael Schumacher', 'Max Verstappen', 'Ayrton Senna'],
      correct: 1
    },
    {
      question: 'Which circuit is known as "The Temple of Speed"?',
      options: ['Monaco', 'Silverstone', 'Monza', 'Spa-Francorchamps'],
      correct: 2
    },
    {
      question: 'What is the maximum number of drivers allowed in a race?',
      options: ['18', '20', '22', '24'],
      correct: 1
    }
  ];

  const handleQuizAnswer = (selectedIndex: number) => {
    if (selectedIndex === quizQuestions[currentQuestion].correct) {
      setQuizScore(quizScore + 1);
    }
    
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      alert(`Quiz Complete! Score: ${quizScore + (selectedIndex === quizQuestions[currentQuestion].correct ? 1 : 0)}/${quizQuestions.length}`);
      setCurrentQuestion(0);
      setQuizScore(0);
      setSelectedGame(null);
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Mini <span className="text-gradient">Games</span>
          </h1>
          <p className="text-dark-400">Play games and earn bonus trading credits</p>
        </motion.div>

        {!selectedGame ? (
          <>
            {/* Daily Rewards */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="card mb-8 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/30"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center text-3xl">
                    🎁
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">Daily Login Bonus</h3>
                    <p className="text-dark-300">Come back every day to claim your reward!</p>
                  </div>
                </div>
                <button className="btn-primary">
                  Claim $200
                </button>
              </div>
            </motion.div>

            {/* Games Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {games.map((game, index) => (
                <motion.div
                  key={game.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="card-hover cursor-pointer"
                  onClick={() => setSelectedGame(game.id)}
                >
                  <div className={`w-full h-32 bg-gradient-to-br ${game.color} rounded-lg flex items-center justify-center text-6xl mb-4 -mx-6 -mt-6`}>
                    {game.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{game.title}</h3>
                  <p className="text-dark-400 mb-4">{game.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Gift className="w-5 h-5 text-yellow-500" />
                      <span className="text-yellow-500 font-bold">Reward: {game.reward}</span>
                    </div>
                    <button className="btn-outline">
                      Play Now
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Leaderboard */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="card mt-8"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Top Players This Week</h2>
              <div className="space-y-3">
                {[
                  { rank: 1, name: 'GameMaster', points: 12500, emoji: '🥇' },
                  { rank: 2, name: 'QuizKing', points: 11200, emoji: '🥈' },
                  { rank: 3, name: 'StrategyPro', points: 10800, emoji: '🥉' }
                ].map((player) => (
                  <div key={player.rank} className="flex items-center gap-4 p-3 bg-dark-800/50 rounded-lg">
                    <span className="text-3xl">{player.emoji}</span>
                    <div className="flex-1">
                      <p className="text-white font-bold">{player.name}</p>
                      <p className="text-dark-400 text-sm">{player.points} points</p>
                    </div>
                    <div className="text-right">
                      <p className="text-yellow-500 font-bold">#{player.rank}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </>
        ) : selectedGame === 'quiz' ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="card max-w-2xl mx-auto"
          >
            <div className="mb-6">
              <button 
                onClick={() => setSelectedGame(null)}
                className="text-dark-400 hover:text-white mb-4"
              >
                ← Back to Games
              </button>
              <h2 className="text-2xl font-bold text-white mb-2">F1 Trivia Challenge</h2>
              <div className="flex items-center justify-between text-sm">
                <p className="text-dark-400">Question {currentQuestion + 1} of {quizQuestions.length}</p>
                <p className="text-green-400 font-bold">Score: {quizScore}</p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-xl text-white font-medium mb-6">{quizQuestions[currentQuestion].question}</h3>
              <div className="space-y-3">
                {quizQuestions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuizAnswer(index)}
                    className="w-full p-4 bg-dark-800 hover:bg-dark-700 text-white rounded-lg text-left transition-colors"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card text-center py-20"
          >
            <Gamepad2 className="w-20 h-20 text-dark-600 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-white mb-4">Coming Soon!</h2>
            <p className="text-dark-400 mb-8">This game is under development</p>
            <button onClick={() => setSelectedGame(null)} className="btn-primary">
              Back to Games
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Games;