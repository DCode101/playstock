import React, { useEffect, useState } from 'react';
import { useAppStore } from '../store/appStore';
import { TrendingUp, TrendingDown, DollarSign, Briefcase, Trophy, Zap, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

const Dashboard: React.FC = () => {
  const { user, drivers } = useAppStore();
  const [portfolioValue, setPortfolioValue] = useState(0);
  const [totalReturn, setTotalReturn] = useState(0);
  const [topDrivers, setTopDrivers] = useState<any[]>([]);

  useEffect(() => {
    // Calculate portfolio value
    if (user?.portfolio && drivers.length > 0) {
      const value = user.portfolio.reduce((total, item) => {
        const driver = drivers.find(d => d.id === item.driverId);
        return total + (driver ? driver.price * item.shares : 0);
      }, 0);
      setPortfolioValue(value);
      setTotalReturn(value + user.balance - 100000);
    }

    // Get top 5 drivers by price
    const sorted = [...drivers].sort((a, b) => b.price - a.price).slice(0, 5);
    setTopDrivers(sorted);
  }, [user, drivers]);

  const stats = [
    {
      label: 'Total Balance',
      value: `$${(user?.balance || 0).toLocaleString()}`,
      change: '+0.0%',
      isPositive: true,
      icon: DollarSign,
      color: 'from-blue-500 to-blue-600'
    },
    {
      label: 'Portfolio Value',
      value: `$${portfolioValue.toLocaleString()}`,
      change: totalReturn >= 0 ? '+' : '',
      changeValue: totalReturn.toFixed(2),
      isPositive: totalReturn >= 0,
      icon: Briefcase,
      color: 'from-purple-500 to-purple-600'
    },
    {
      label: 'Total Net Worth',
      value: `$${((user?.balance || 0) + portfolioValue).toLocaleString()}`,
      change: totalReturn >= 0 ? `+${((totalReturn / 100000) * 100).toFixed(2)}%` : `${((totalReturn / 100000) * 100).toFixed(2)}%`,
      isPositive: totalReturn >= 0,
      icon: Trophy,
      color: 'from-green-500 to-green-600'
    },
    {
      label: 'Active Positions',
      value: user?.portfolio?.length || 0,
      icon: Zap,
      color: 'from-orange-500 to-orange-600'
    }
  ];

  // Mock chart data
  const chartData = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    value: 100000 + Math.random() * 20000 - 10000
  }));

  return (
    <div className="min-h-screen bg-dark-950 p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Welcome back, <span className="text-gradient">{user?.username}</span>! 🏎️
          </h1>
          <p className="text-dark-400">Here's what's happening with your F1 portfolio today</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="card-hover group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color} shadow-lg group-hover:scale-110 transition-transform`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                {stat.change && (
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                    stat.isPositive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {stat.isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {stat.change}
                  </div>
                )}
              </div>
              <p className="text-dark-400 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl md:text-3xl font-bold text-white">{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Portfolio Performance Chart */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-2 card"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-white mb-1">Portfolio Performance</h2>
                <p className="text-dark-400 text-sm">Last 30 days</p>
              </div>
              <div className="flex gap-2">
                <button className="px-3 py-1 text-xs bg-primary-600 text-white rounded-lg">30D</button>
                <button className="px-3 py-1 text-xs bg-dark-800 text-dark-400 rounded-lg hover:bg-dark-700">90D</button>
                <button className="px-3 py-1 text-xs bg-dark-800 text-dark-400 rounded-lg hover:bg-dark-700">1Y</button>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="#4b5563" />
                <YAxis stroke="#4b5563" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
                  labelStyle={{ color: '#9ca3af' }}
                />
                <Area type="monotone" dataKey="value" stroke="#ef4444" fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Top Drivers */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="card"
          >
            <h2 className="text-xl font-bold text-white mb-4">Top Drivers</h2>
            <div className="space-y-3">
              {topDrivers.map((driver, index) => (
                <motion.div
                  key={driver.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  className="flex items-center gap-3 p-3 bg-dark-800/50 rounded-lg hover:bg-dark-800 transition-colors cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 border-2 border-dark-700 group-hover:border-primary-600 transition-colors">
                    <img 
                      src={driver.photo} 
                      alt={driver.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${driver.name}&background=random`;
                      }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium text-sm truncate">{driver.name}</p>
                    <p className="text-dark-400 text-xs">{driver.team}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-bold text-sm">${driver.price}</p>
                    <p className={`text-xs ${driver.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {driver.change >= 0 ? '+' : ''}{driver.changePercent?.toFixed(2)}%
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Quick Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="grid md:grid-cols-3 gap-4"
        >
          <div className="card-hover bg-gradient-to-br from-primary-600 to-red-600 text-white cursor-pointer group">
            <div className="flex items-center justify-between mb-3">
              <TrendingUp className="w-8 h-8 group-hover:scale-110 transition-transform" />
              <ArrowUpRight className="w-5 h-5 opacity-50" />
            </div>
            <h3 className="text-xl font-bold mb-1">Explore Market</h3>
            <p className="text-white/80 text-sm">Discover trending drivers</p>
          </div>

          <div className="card-hover bg-gradient-to-br from-purple-600 to-pink-600 text-white cursor-pointer group">
            <div className="flex items-center justify-between mb-3">
              <Briefcase className="w-8 h-8 group-hover:scale-110 transition-transform" />
              <ArrowUpRight className="w-5 h-5 opacity-50" />
            </div>
            <h3 className="text-xl font-bold mb-1">View Portfolio</h3>
            <p className="text-white/80 text-sm">Manage your holdings</p>
          </div>

          <div className="card-hover bg-gradient-to-br from-green-600 to-teal-600 text-white cursor-pointer group">
            <div className="flex items-center justify-between mb-3">
              <Trophy className="w-8 h-8 group-hover:scale-110 transition-transform" />
              <ArrowUpRight className="w-5 h-5 opacity-50" />
            </div>
            <h3 className="text-xl font-bold mb-1">Leaderboard</h3>
            <p className="text-white/80 text-sm">See your ranking</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;