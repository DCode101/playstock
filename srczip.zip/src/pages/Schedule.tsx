import React, { useEffect, useState } from 'react';
import { Calendar, MapPin, Clock, CheckCircle, Radio, Flag } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAppStore } from '../store/appStore';

const Schedule: React.FC = () => {
  const { races } = useAppStore();
  const [upcomingRaces, setUpcomingRaces] = useState<any[]>([]);
  const [completedRaces, setCompletedRaces] = useState<any[]>([]);

  useEffect(() => {
    const now = new Date();
    const upcoming = races.filter(r => new Date(r.date) >= now);
    const completed = races.filter(r => new Date(r.date) < now);
    
    setUpcomingRaces(upcoming);
    setCompletedRaces(completed);
  }, [races]);

  return (
    <div className="min-h-screen bg-black p-4 md:p-6 lg:p-8 relative">
      <div className="racing-stripes fixed inset-0 opacity-20 pointer-events-none" />
      
      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="racing-header mb-4">
            RACE SCHEDULE
          </h1>
          <p className="text-gray-400 text-lg">2026 Formula 1 Championship Calendar</p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <motion.div className="stat-card text-center">
            <Flag className="w-8 h-8 text-racing-red mx-auto mb-2" />
            <p className="text-gray-400 text-sm">Total Races</p>
            <p className="text-3xl font-black text-white">{races.length}</p>
          </motion.div>
          <motion.div className="stat-card text-center">
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-gray-400 text-sm">Completed</p>
            <p className="text-3xl font-black text-white">{completedRaces.length}</p>
          </motion.div>
          <motion.div className="stat-card text-center">
            <Calendar className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <p className="text-gray-400 text-sm">Upcoming</p>
            <p className="text-3xl font-black text-white">{upcomingRaces.length}</p>
          </motion.div>
        </div>

        {/* Upcoming Races */}
        {upcomingRaces.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-black text-white mb-4 uppercase tracking-wide">Upcoming Races</h2>
            <div className="space-y-4">
              {upcomingRaces.map((race, index) => (
                <motion.div
                  key={race.round}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="card-hover"
                >
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-racing-red to-racing-darkRed rounded-xl flex-shrink-0 font-black text-white text-2xl">
                      {race.round}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-black text-white uppercase">{race.raceName}</h3>
                        {race.isLive && (
                          <span className="flex items-center gap-1 px-2 py-1 bg-red-500 text-white text-xs font-black rounded-full animate-pulse">
                            <Radio className="w-3 h-3" />
                            LIVE
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {race.circuit.location}, {race.circuit.country}
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          {new Date(race.date).toLocaleDateString('en-US', { 
                            weekday: 'short',
                            month: 'long', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })}
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          {race.time}
                        </div>
                      </div>
                    </div>

                    <button className="btn-outline md:w-32">
                      Details
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Races */}
        {completedRaces.length > 0 && (
          <div>
            <h2 className="text-2xl font-black text-white mb-4 uppercase tracking-wide">Completed Races</h2>
            <div className="space-y-3">
              {completedRaces.map((race, index) => (
                <motion.div
                  key={race.round}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className="card opacity-75 hover:opacity-100 transition-opacity"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-racing-gray rounded-lg flex items-center justify-center font-bold text-white">
                      {race.round}
                    </div>
                    <CheckCircle className="w-6 h-6 text-green-400" />
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white">{race.raceName}</h3>
                      <p className="text-sm text-gray-400">{race.circuit.location}</p>
                    </div>
                    <p className="text-sm text-gray-400">
                      {new Date(race.date).toLocaleDateString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Schedule;