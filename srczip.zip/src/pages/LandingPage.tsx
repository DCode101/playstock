import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Zap, Trophy, Users } from 'lucide-react';

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
              Invest in <span className="text-gradient">F1 Drivers</span>
            </h1>
            <p className="text-xl md:text-2xl text-dark-300 mb-8 max-w-3xl mx-auto">
              Trade Formula 1 drivers like stocks. Build your portfolio, track real-time performance, and compete with fans worldwide.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/signup" className="btn-primary text-lg px-8 py-4">
                Start Trading Free
              </Link>
              <Link to="/login" className="btn-outline text-lg px-8 py-4">
                Login
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: TrendingUp,
              title: 'Real-Time Data',
              description: 'Live race updates and driver performance tracking'
            },
            {
              icon: Zap,
              title: 'Dynamic Pricing',
              description: 'Driver values change based on actual race results'
            },
            {
              icon: Trophy,
              title: 'Compete Globally',
              description: 'Climb the leaderboard and earn achievements'
            },
            {
              icon: Users,
              title: 'Join Community',
              description: 'Trade with thousands of F1 fans worldwide'
            }
          ].map((feature, index) => (
            <div key={index} className="card text-center">
              <feature.icon className="w-12 h-12 text-primary-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-dark-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
