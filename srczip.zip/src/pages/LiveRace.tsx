import React, { useState, useEffect } from 'react';
import { Radio, Flag, Clock, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAppStore } from '../store/appStore';

const LiveRace: React.FC = () => {
  const { drivers } = useAppStore();
  const [isLive, setIsLive] = useState(false);
  const [currentLap, setCurrentLap] = useState(1);
  const [totalLaps, setTotalLaps] = useState(58);

  // Simulate live positions
  const [positions, setPositions] = useState(
    [...drivers]
      .sort((a, b) => (a.rank || 0) - (b.rank || 0))
      .slice(0, 20)
      .map((driver, index) => ({
        ...driver,
        position: index + 1,
        gap: index === 0 ? 'Leader' : `+${(index * 2.3).toFixed(3)}`,
        lastLapTime: `1:${20 + Math.random() * 10 | 0}.${Math.random() * 999 | 0}`,
        pitstops: Math.floor(Math.random() * 3)
      }))
  );

  return (
    <div className="min-h-screen bg-dark-950 p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
                <span className="text-gradient">Live</span> Race Tracker
              </h1>
              <p className="text-dark-400">Real-time race positions and lap times</p>
            </div>
            {isLive && (
              <div className="flex items-center gap-2 px-4 py-2 bg-red-500 rounded-full animate-pulse">
                <Radio className="w-5 h-5 text-white" />
                <span className="text-white font-bold">LIVE</span>
              </div>
            )}
          </div>
        </motion.div>

        {!isLive ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card text-center py-20"
          >
            <Flag className="w-20 h-20 text-dark-600 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-white mb-4">No Live Race</h2>
            <p className="text-dark-400 mb-8">The next race will begin soon. Check the schedule for upcoming races.</p>
            <button className="btn-primary">View Schedule</button>
          </motion.div>
        ) : (
          <>
            {/* Race Info */}
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="card bg-gradient-to-br from-primary-600 to-red-600 text-white">
                <div className="flex items-center gap-3">
                  <Flag className="w-8 h-8" />
                  <div>
                    <p className="text-white/80 text-sm">Current Lap</p>
                    <p className="text-2xl font-bold">{currentLap} / {totalLaps}</p>
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="flex items-center gap-3">
                  <Clock className="w-8 h-8 text-primary-500" />
                  <div>
                    <p className="text-dark-400 text-sm">Elapsed Time</p>
                    <p className="text-2xl font-bold text-white">1:23:45</p>
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="flex items-center gap-3">
                  <Zap className="w-8 h-8 text-yellow-500" />
                  <div>
                    <p className="text-dark-400 text-sm">Track Status</p>
                    <p className="text-2xl font-bold text-green-400">Green Flag</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Positions Table */}
            <div className="card overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-dark-800">
                    <th className="text-left text-dark-400 text-sm font-medium p-3">Pos</th>
                    <th className="text-left text-dark-400 text-sm font-medium p-3">Driver</th>
                    <th className="text-left text-dark-400 text-sm font-medium p-3">Team</th>
                    <th className="text-left text-dark-400 text-sm font-medium p-3">Gap</th>
                    <th className="text-left text-dark-400 text-sm font-medium p-3">Last Lap</th>
                    <th className="text-left text-dark-400 text-sm font-medium p-3">Pits</th>
                  </tr>
                </thead>
                <tbody>
                  {positions.map((driver, index) => (
                    <motion.tr
                      key={driver.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className="border-b border-dark-800 hover:bg-dark-800/50 transition-colors"
                    >
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                            driver.position === 1 ? 'bg-yellow-500 text-dark-900' :
                            driver.position === 2 ? 'bg-gray-400 text-dark-900' :
                            driver.position === 3 ? 'bg-orange-600 text-white' :
                            'bg-dark-700 text-white'
                          }`}>
                            {driver.position}
                          </div>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <img 
                            src={driver.photo}
                            alt={driver.name}
                            className="w-10 h-10 rounded-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${driver.name}&background=random`;
                            }}
                          />
                          <span className="text-white font-medium">{driver.name}</span>
                        </div>
                      </td>
                      <td className="p-3 text-dark-300">{driver.team}</td>
                      <td className="p-3 text-white font-mono text-sm">{driver.gap}</td>
                      <td className="p-3 text-white font-mono text-sm">{driver.lastLapTime}</td>
                      <td className="p-3 text-white">{driver.pitstops}</td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default LiveRace;