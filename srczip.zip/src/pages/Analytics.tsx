import React, { useEffect, useState } from 'react';
import { BarChart3, PieChart as PieChartIcon, Activity, Target, TrendingUp, DollarSign } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';
import { useAppStore } from '../store/appStore';

const Analytics: React.FC = () => {
  const { user, drivers } = useAppStore();
  const [stats, setStats] = useState({
    totalInvested: 0,
    currentValue: 0,
    totalReturn: 0,
    returnPercent: 0,
    totalTrades: 0,
    winRate: 0,
    bestTrade: 0,
    worstTrade: 0,
    avgHoldTime: 0
  });
  const [portfolioData, setPortfolioData] = useState<any[]>([]);
  const [teamDistribution, setTeamDistribution] = useState<any[]>([]);
  const [performanceHistory, setPerformanceHistory] = useState<any[]>([]);

  useEffect(() => {
    if (user && drivers.length > 0) {
      calculateAnalytics();
    }
  }, [user, drivers]);

  const calculateAnalytics = () => {
    if (!user?.portfolio || user.portfolio.length === 0) return;

    let totalInvested = 0;
    let currentValue = 0;
    const enrichedPortfolio: any[] = [];
    const teamMap = new Map<string, number>();

    user.portfolio.forEach(item => {
      const driver = drivers.find(d => d.id === item.driverId);
      if (!driver) return;

      const invested = item.avgBuyPrice * item.shares;
      const current = driver.price * item.shares;
      const returnVal = current - invested;
      const returnPct = (returnVal / invested) * 100;

      totalInvested += invested;
      currentValue += current;

      enrichedPortfolio.push({
        driver: driver.name,
        team: driver.team,
        invested,
        current,
        return: returnVal,
        returnPercent: returnPct,
        shares: item.shares
      });

      // Team distribution
      const teamValue = teamMap.get(driver.team) || 0;
      teamMap.set(driver.team, teamValue + current);
    });

    const totalReturn = currentValue - totalInvested;
    const returnPercent = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;

    // Calculate best and worst trades
    const returns = enrichedPortfolio.map(p => p.return);
    const bestTrade = Math.max(...returns, 0);
    const worstTrade = Math.min(...returns, 0);

    // Win rate
    const profitableTrades = enrichedPortfolio.filter(p => p.return > 0).length;
    const winRate = enrichedPortfolio.length > 0 ? (profitableTrades / enrichedPortfolio.length) * 100 : 0;

    setStats({
      totalInvested,
      currentValue,
      totalReturn,
      returnPercent,
      totalTrades: user.portfolio.length,
      winRate,
      bestTrade,
      worstTrade,
      avgHoldTime: 0
    });

    setPortfolioData(enrichedPortfolio);

    // Team distribution for pie chart
    const teamDist = Array.from(teamMap.entries()).map(([team, value]) => ({
      team,
      value,
      percent: (value / currentValue) * 100,
      color: drivers.find(d => d.team === team)?.teamColor || '#888'
    }));

    setTeamDistribution(teamDist);

    // Performance history (mock for now, should be from netWorthHistory)
    const history = user.netWorthHistory || [];
    if (history.length > 0) {
      setPerformanceHistory(history.map((h: any, i: number) => ({
        day: i + 1,
        value: h.value
      })));
    } else {
      // Generate from current data
      const days = 30;
      const histData = [];
      for (let i = 0; i < days; i++) {
        histData.push({
          day: i + 1,
          value: 100000 + (currentValue - 100000) * (i / days)
        });
      }
      setPerformanceHistory(histData);
    }
  };

  return (
    <div className="min-h-screen bg-black p-4 md:p-6 lg:p-8 relative">
      <div className="racing-stripes fixed inset-0 opacity-20 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="racing-header mb-4">
            PORTFOLIO ANALYTICS
          </h1>
          <p className="text-gray-400 text-lg">Deep dive into your trading performance</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { 
              label: 'Total Invested', 
              value: '$' + stats.totalInvested.toLocaleString(), 
              icon: DollarSign, 
              color: 'from-blue-500 to-blue-600' 
            },
            { 
              label: 'Current Value', 
              value: '$' + stats.currentValue.toLocaleString(), 
              icon: Activity, 
              color: 'from-purple-500 to-purple-600' 
            },
            { 
              label: 'Total Return', 
              value: (stats.totalReturn >= 0 ? '+$' : '-$') + Math.abs(stats.totalReturn).toLocaleString(), 
              icon: TrendingUp, 
              color: stats.totalReturn >= 0 ? 'from-green-500 to-green-600' : 'from-red-500 to-red-600',
              valueColor: stats.totalReturn >= 0 ? 'text-green-400' : 'text-red-400'
            },
            { 
              label: 'Return %', 
              value: (stats.returnPercent >= 0 ? '+' : '') + stats.returnPercent.toFixed(2) + '%', 
              icon: Target, 
              color: stats.returnPercent >= 0 ? 'from-green-500 to-green-600' : 'from-red-500 to-red-600',
              valueColor: stats.returnPercent >= 0 ? 'text-green-400' : 'text-red-400'
            },
            { 
              label: 'Win Rate', 
              value: stats.winRate.toFixed(1) + '%', 
              icon: Target, 
              color: 'from-yellow-500 to-orange-500' 
            },
            { 
              label: 'Total Positions', 
              value: stats.totalTrades, 
              icon: BarChart3, 
              color: 'from-indigo-500 to-purple-600' 
            },
            { 
              label: 'Best Trade', 
              value: '+$' + stats.bestTrade.toLocaleString(), 
              icon: TrendingUp, 
              color: 'from-green-500 to-emerald-600',
              valueColor: 'text-green-400'
            },
            { 
              label: 'Worst Trade', 
              value: stats.worstTrade < 0 ? '-$' + Math.abs(stats.worstTrade).toLocaleString() : '$0', 
              icon: Activity, 
              color: 'from-red-500 to-red-600',
              valueColor: 'text-red-400'
            }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="card"
            >
              <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${stat.color} mb-3 shadow-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-gray-400 text-sm mb-1 uppercase tracking-wide">{stat.label}</p>
              <p className={`text-2xl font-black ${stat.valueColor || 'text-white'}`}>{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {portfolioData.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card text-center py-20"
          >
            <PieChartIcon className="w-20 h-20 text-gray-600 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-white mb-4">No Portfolio Data</h2>
            <p className="text-gray-400 mb-8">Start investing in drivers to see analytics</p>
            <button className="btn-primary">Go to Market</button>
          </motion.div>
        ) : (
          <>
            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6 mb-8">
              {/* Performance Chart */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="card"
              >
                <h2 className="text-xl font-black text-white mb-6 uppercase tracking-wide">Portfolio Value Trend</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceHistory}>
                    <XAxis dataKey="day" stroke="#666" />
                    <YAxis stroke="#666" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1A1A1A', 
                        border: '1px solid #E10600', 
                        borderRadius: '8px',
                        color: '#fff'
                      }}
                      formatter={(value: any) => ['$' + value.toLocaleString(), 'Value']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#E10600" 
                      strokeWidth={3} 
                      dot={false}
                      activeDot={{ r: 6, fill: '#E10600' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </motion.div>

              {/* Holdings Breakdown */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="card"
              >
                <h2 className="text-xl font-black text-white mb-6 uppercase tracking-wide">Holdings Performance</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={portfolioData}>
                    <XAxis dataKey="driver" stroke="#666" angle={-45} textAnchor="end" height={100} />
                    <YAxis stroke="#666" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1A1A1A', 
                        border: '1px solid #E10600', 
                        borderRadius: '8px',
                        color: '#fff'
                      }}
                      formatter={(value: any) => '$' + value.toLocaleString()}
                    />
                    <Bar dataKey="return" radius={[8, 8, 0, 0]}>
                      {portfolioData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.return >= 0 ? '#10b981' : '#ef4444'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </motion.div>
            </div>

            {/* Team Distribution */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="card"
            >
              <h2 className="text-xl font-black text-white mb-6 uppercase tracking-wide">Portfolio Distribution by Team</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={teamDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {teamDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1A1A1A', 
                          border: '1px solid #E10600', 
                          borderRadius: '8px',
                          color: '#fff'
                        }}
                        formatter={(value: any) => '$' + value.toLocaleString()}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-3">
                  {teamDistribution.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center justify-between p-3 bg-racing-black/50 rounded-lg border border-racing-red/20"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded" style={{ backgroundColor: item.color }} />
                        <span className="text-white font-bold">{item.team}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-bold">${item.value.toLocaleString()}</p>
                        <p className="text-gray-400 text-sm">{item.percent.toFixed(1)}%</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </div>
    </div>
  );
};

export default Analytics;