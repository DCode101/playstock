import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { Search, TrendingUp, TrendingDown, Filter, ShoppingCart, Zap, Target, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Market: React.FC = () => {
  const { drivers, user, setUser } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'price' | 'change' | 'name'>('price');
  const [filterTeam, setFilterTeam] = useState('all');
  const [selectedDriver, setSelectedDriver] = useState<any>(null);
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [shares, setShares] = useState(1);
  const [loading, setLoading] = useState(false);

  const teams = ['all', ...new Set(drivers.map(d => d.team))];

  const filteredDrivers = drivers
    .filter(driver => 
      driver.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (filterTeam === 'all' || driver.team === filterTeam)
    )
    .sort((a, b) => {
      if (sortBy === 'price') return b.price - a.price;
      if (sortBy === 'change') return (b.changePercent || 0) - (a.changePercent || 0);
      return a.name.localeCompare(b.name);
    });

  const handleBuy = async () => {
    if (!selectedDriver || !user || loading) return;
    
    const totalCost = selectedDriver.price * shares;
    if (user.balance < totalCost) {
      alert('Insufficient balance!');
      return;
    }

    setLoading(true);

    try {
      // Update user portfolio and balance
      const existingPosition = user.portfolio.find(p => p.driverId === selectedDriver.id);
      
      const newPortfolio = existingPosition
        ? user.portfolio.map(p => 
            p.driverId === selectedDriver.id
              ? { 
                  ...p, 
                  shares: p.shares + shares, 
                  avgBuyPrice: ((p.avgBuyPrice * p.shares) + totalCost) / (p.shares + shares) 
                }
              : p
          )
        : [...user.portfolio, { 
            driverId: selectedDriver.id, 
            shares, 
            avgBuyPrice: selectedDriver.price, 
            currentPrice: selectedDriver.price, 
            totalValue: totalCost, 
            totalReturn: 0, 
            totalReturnPercent: 0, 
            purchaseDate: Date.now() 
          }];

      const updatedUser = {
        ...user,
        balance: user.balance - totalCost,
        portfolio: newPortfolio
      };

      // Update Firestore
      await updateDoc(doc(db, 'users', user.uid), {
        balance: updatedUser.balance,
        portfolio: updatedUser.portfolio
      });

      setUser(updatedUser);
      setShowBuyModal(false);
      setShares(1);
      setSelectedDriver(null);
    } catch (error) {
      console.error('Error buying shares:', error);
      alert('Failed to complete purchase. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black p-4 md:p-6 lg:p-8 relative">
      {/* Racing stripes background */}
      <div className="racing-stripes fixed inset-0 opacity-20 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="racing-header mb-4">
            DRIVER MARKET
          </h1>
          <p className="text-gray-400 text-lg">Buy and sell F1 drivers based on their performance</p>
        </motion.div>

        {/* Market Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
        >
          {[
            { label: 'Total Drivers', value: drivers.length, icon: Target, color: 'from-racing-red to-red-600' },
            { label: 'Market Volume', value: '$' + (drivers.reduce((sum, d) => sum + (d.volume24h || 0), 0) / 1000000).toFixed(1) + 'M', icon: Activity, color: 'from-orange-500 to-red-500' },
            { label: 'Avg Price', value: '$' + Math.round(drivers.reduce((sum, d) => sum + d.price, 0) / drivers.length), icon: TrendingUp, color: 'from-green-500 to-emerald-600' },
            { label: 'Your Balance', value: '$' + (user?.balance || 0).toLocaleString(), icon: Zap, color: 'from-yellow-500 to-orange-500' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="stat-card"
            >
              <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${stat.color} mb-3 shadow-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-gray-400 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card mb-6 racing-border"
        >
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="Search drivers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-10"
              />
            </div>

            {/* Sort */}
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="input-field md:w-48"
            >
              <option value="price">Price: High to Low</option>
              <option value="change">Change: High to Low</option>
              <option value="name">Name: A to Z</option>
            </select>

            {/* Filter Team */}
            <select 
              value={filterTeam}
              onChange={(e) => setFilterTeam(e.target.value)}
              className="input-field md:w-56"
            >
              {teams.map(team => (
                <option key={team} value={team}>
                  {team === 'all' ? '🏁 All Teams' : team}
                </option>
              ))}
            </select>
          </div>
        </motion.div>

        {/* Driver Grid */}
        {filteredDrivers.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card text-center py-20"
          >
            <p className="text-2xl text-gray-400 mb-4">No drivers found</p>
            <p className="text-gray-500">Try adjusting your search or filters</p>
          </motion.div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredDrivers.map((driver, index) => (
                <motion.div
                  key={driver.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.03 }}
                  className="card-hover group relative overflow-hidden"
                  onClick={() => {
                    setSelectedDriver(driver);
                    setShowBuyModal(true);
                  }}
                >
                  {/* Driver Image Background */}
                  <div 
                    className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity duration-300"
                    style={{
                      background: `linear-gradient(135deg, ${driver.teamColor}20 0%, transparent 100%)`
                    }}
                  />

                  {/* Driver Photo */}
                  <div className="relative h-56 -mx-6 -mt-6 mb-4 overflow-hidden rounded-t-2xl" style={{ backgroundColor: `${driver.teamColor}15` }}>
                    <motion.img 
                      src={driver.photo}
                      alt={driver.name}
                      className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(driver.name)}&background=E10600&color=fff&size=400&bold=true`;
                      }}
                      whileHover={{ scale: 1.05 }}
                    />
                    
                    {/* Driver Number Badge */}
                    <div className="absolute top-4 right-4 w-12 h-12 bg-racing-red rounded-full flex items-center justify-center border-2 border-white shadow-lg glow-effect">
                      <span className="text-white font-black text-lg">{driver.driverNumber}</span>
                    </div>

                    {/* Risk Badge */}
                    <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-bold uppercase ${
                      driver.risk === 'low' ? 'bg-green-500/90 text-white' :
                      driver.risk === 'medium' ? 'bg-yellow-500/90 text-black' :
                      'bg-red-500/90 text-white'
                    } shadow-lg backdrop-blur-sm`}>
                      {driver.risk} RISK
                    </div>
                  </div>

                  {/* Driver Info */}
                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="text-xl font-black text-white mb-1 uppercase tracking-wide">{driver.name}</h3>
                        <p className="text-gray-400 text-sm flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: driver.teamColor }} />
                          {driver.team}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-black text-white neon-text">${driver.price}</p>
                        <div className={`flex items-center gap-1 text-sm font-bold ${(driver.changePercent || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {(driver.changePercent || 0) >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                          {(driver.changePercent || 0) >= 0 ? '+' : ''}{(driver.changePercent || 0).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="bg-racing-black/50 rounded-lg p-2 text-center border border-racing-red/20">
                        <p className="text-gray-400 text-xs mb-1">Rank</p>
                        <p className="text-white font-bold text-lg">P{driver.rank}</p>
                      </div>
                      <div className="bg-racing-black/50 rounded-lg p-2 text-center border border-racing-red/20">
                        <p className="text-gray-400 text-xs mb-1">Points</p>
                        <p className="text-white font-bold text-lg">{driver.points || 0}</p>
                      </div>
                      <div className="bg-racing-black/50 rounded-lg p-2 text-center border border-racing-red/20">
                        <p className="text-gray-400 text-xs mb-1">Wins</p>
                        <p className="text-white font-bold text-lg">{driver.wins || 0}</p>
                      </div>
                    </div>

                    {/* Buy Button */}
                    <button className="btn-primary w-full flex items-center justify-center gap-2 font-black uppercase">
                      <ShoppingCart className="w-5 h-5" />
                      BUY SHARES
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* Buy Modal */}
        <AnimatePresence>
          {showBuyModal && selectedDriver && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4"
              onClick={() => !loading && setShowBuyModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="card max-w-md w-full racing-border glow-effect"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-4 mb-6">
                  <img 
                    src={selectedDriver.photo}
                    alt={selectedDriver.name}
                    className="w-20 h-20 rounded-full object-cover border-4 border-racing-red"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedDriver.name)}&background=E10600&color=fff&size=200&bold=true`;
                    }}
                  />
                  <div>
                    <h2 className="text-2xl font-black text-white uppercase">{selectedDriver.name}</h2>
                    <p className="text-gray-400">{selectedDriver.team}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4 p-4 bg-racing-black/50 rounded-lg border border-racing-red/30">
                    <div>
                      <p className="text-gray-400 text-sm mb-1">Price per share</p>
                      <p className="text-3xl font-black text-white">${selectedDriver.price}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-gray-400 text-sm mb-1">Your balance</p>
                      <p className="text-xl font-bold text-green-400">${user?.balance.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-gray-300 text-sm font-bold mb-2 uppercase">Number of shares</label>
                    <input
                      type="number"
                      min="1"
                      max={Math.floor((user?.balance || 0) / selectedDriver.price)}
                      value={shares}
                      onChange={(e) => setShares(Math.max(1, parseInt(e.target.value) || 1))}
                      className="input-field text-2xl font-bold text-center"
                      disabled={loading}
                    />
                  </div>

                  <div className="bg-racing-red/10 border border-racing-red/30 rounded-lg p-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-400 font-medium">Total Cost</span>
                      <span className="text-white font-black text-lg">${(selectedDriver.price * shares).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400 font-medium">Remaining Balance</span>
                      <span className="text-white font-black text-lg">${((user?.balance || 0) - (selectedDriver.price * shares)).toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button 
                    onClick={() => !loading && setShowBuyModal(false)}
                    className="btn-secondary flex-1 uppercase font-black"
                    disabled={loading}
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleBuy}
                    className="btn-primary flex-1 uppercase font-black"
                    disabled={(user?.balance || 0) < selectedDriver.price * shares || loading}
                  >
                    {loading ? 'Processing...' : 'Buy Now'}
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Market;