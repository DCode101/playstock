import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Driver, User, MarketState, Race } from '../types';

interface AppState {
  // User state
  user: User | null;
  setUser: (user: User | null) => void;
  updateBalance: (balance: number) => void;
  
  // Drivers state
  drivers: Driver[];
  setDrivers: (drivers: Driver[]) => void;
  updateDriverPrice: (driverId: string, price: number, change: number) => void;
  
  // Market state
  marketState: MarketState;
  setMarketState: (state: MarketState) => void;
  
  // Schedule state
  races: Race[];
  setRaces: (races: Race[]) => void;
  
  // UI state
  currentView: string;
  setCurrentView: (view: string) => void;
  
  // Loading states
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  
  // Tutorial
  showTutorial: boolean;
  setShowTutorial: (show: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Initial state
      user: null,
      drivers: [],
      marketState: {
        vix: 45,
        sentiment: 'bullish',
        activeConnections: 0,
        globalVolume: 0,
        topMovers: {
          gainers: [],
          losers: [],
        },
      },
      races: [],
      currentView: 'landing',
      isLoading: false,
      showTutorial: false,

      // Actions
      setUser: (user) => set({ user }),
      
      updateBalance: (balance) =>
        set((state) => ({
          user: state.user ? { ...state.user, balance } : null,
        })),

      setDrivers: (drivers) => set({ drivers }),
      
      updateDriverPrice: (driverId, price, change) =>
        set((state) => ({
          drivers: state.drivers.map((driver) =>
            driver.id === driverId
              ? {
                  ...driver,
                  price,
                  change,
                  changePercent: (change / driver.basePrice) * 100,
                }
              : driver
          ),
        })),

      setMarketState: (marketState) => set({ marketState }),
      
      setRaces: (races) => set({ races }),
      
      setCurrentView: (currentView) => set({ currentView }),
      
      setIsLoading: (isLoading) => set({ isLoading }),
      
      setShowTutorial: (showTutorial) => set({ showTutorial }),
    }),
    {
      name: 'f1-playstock-storage',
      partialize: (state) => ({
        showTutorial: state.showTutorial,
      }),
    }
  )
);
